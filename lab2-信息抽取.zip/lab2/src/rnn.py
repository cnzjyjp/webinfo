import torch
import nltk
import collections
import os
import time
from torch import nn
import torchtext.vocab as Vocab
import torch.utils.data as Data
from nltk.tokenize import word_tokenize


def load_data():
    # 载入训练和测试数据，简单分词处理
    # data_train和data_test是由[tokenlist]组成的list，tags是对应于data_train的实体关系
    train_file = '../data/train.txt'
    test_file = '../data/test.txt'
    data_train, data_test = [], []
    tags_relation, tags_entity = [], []
    with open(train_file, 'r') as f:
        line1, line2 = f.readline(), f.readline()
        while line1 != '':
            tokens = word_tokenize(line1.lower())
            tags = word_tokenize(line2)
            data_train.append([token for token in tokens[2:-1]])
            tags_relation.append(tags[0])
            tags_entity.append([tags[tags.index('(') + 1: tags.index(',')],
                                tags[tags.index(',') + 1: -1]])
            line1, line2 = f.readline(), f.readline()
    with open(test_file, 'r') as f:
        line = f.readline()
        while line != '':
            tokens = word_tokenize(line.lower())
            data_test.append([token for token in tokens[2:-1]])
            line = f.readline()
    return data_train, tags_relation, tags_entity, data_test


def data_to_tensor(data, vocab):
    max_l = 80

    def pad(x):
        return x[:max_l] if len(x) > max_l else x + [0] * (max_l - len(x))

    tensor = torch.tensor([pad([vocab.stoi[token] for token in tokens]) for tokens in data])
    return tensor


class BiRNN(nn.Module):
    def __init__(self, vocab, embed_size, num_hiddens, num_layers, class_num):
        super(BiRNN, self).__init__()
        self.embedding = nn.Embedding(len(vocab), embed_size)
        # bidirectional设为True即得到双向循环神经网络
        self.encoder = nn.LSTM(input_size=embed_size,
                               hidden_size=num_hiddens,
                               num_layers=num_layers,
                               bidirectional=True)
        # 初始时间步和最终时间步的隐藏状态作为全连接层输入
        self.decoder_relation = nn.Linear(4 * num_hiddens, class_num)
        self.decoder_entity = nn.Linear(2 * num_hiddens, 5)  # BOIES 5种标记

    def forward(self, inputs):
        # inputs的形状是(批量大小, 词数)，因为LSTM需要将序列长度(seq_len)作为第一维，所以将输入转置后
        # 再提取词特征，输出形状为(词数, 批量大小, 词向量维度)
        embeddings = self.embedding(inputs.permute(1, 0))
        # rnn.LSTM只传入输入embeddings，因此只返回最后一层的隐藏层在各时间步的隐藏状态。
        # outputs形状是(词数, 批量大小, 2 * 隐藏单元个数)
        outputs, _ = self.encoder(embeddings)  # output, (h, c)
        # 连结初始时间步和最终时间步的隐藏状态作为全连接层输入。它的形状为
        # (批量大小, 4 * 隐藏单元个数)。
        encoding = torch.cat((outputs[0], outputs[-1]), -1)
        outs_relation = self.decoder_relation(encoding)
        outs_entity = self.decoder_entity(outputs.permute(1, 0, 2))
        return outs_relation, outs_entity


def load_pretrained_embedding(words, pretrained_vocab):
    """从预训练好的vocab中提取出words对应的词向量"""
    embed = torch.zeros(len(words), pretrained_vocab.vectors[0].shape[0])  # 初始化为0
    oov_count = 0  # out of vocabulary
    for i, word in enumerate(words):
        try:
            idx = pretrained_vocab.stoi[word]
            embed[i, :] = pretrained_vocab.vectors[idx]
        except KeyError:
            oov_count += 1
    if oov_count > 0:
        print("There are %d oov words." % oov_count)
    return embed


def evaluate_accuracy_relation(data_iter, net, device=None):
    if device is None and isinstance(net, torch.nn.Module):
        # 如果没指定device就使用net的device
        device = list(net.parameters())[0].device
    acc_sum_relation, acc_sum_entity, n = 0.0, 0.0, 0
    with torch.no_grad():
        for X, y_relation, y_entity in data_iter:
            X = X.to(device)
            y_relation = y_relation.to(device)
            y_entity = y_entity.to(device)
            output_relation, output_entity = net(X)
            acc_sum_relation += (output_relation.argmax(dim=1) == y_relation).float().sum().item()
            output_entity = output_entity.argmax(dim=2)
            for x, y in zip(y_entity, output_entity):
                if not (False in (x == y)):
                    acc_sum_entity += 1
            n += y_relation.shape[0]
    return acc_sum_relation / n, acc_sum_entity / n


def train(train_iter, valid_iter, net, loss, optimizer, device, num_epochs):
    net = net.to(device)
    print("training on ", device)
    for epoch in range(num_epochs):
        batch_count = 0
        train_l_sum, train_acc_sum_relation, train_acc_sum_entity, n, start = 0.0, 0.0, 0.0, 0, time.time()
        for x, y_relation, y_entity in train_iter:
            x = x.to(device)
            y_relation = y_relation.to(device)
            y_entity = y_entity.to(device)
            output_relation, output_entity = net(x)
            l = loss(output_relation, y_relation) + loss(output_entity.permute(0, 2, 1), y_entity).sum(dim=1)
            l = l.mean()
            optimizer.zero_grad()
            l.backward()
            optimizer.step()
            train_l_sum += l.cpu().item()
            train_acc_sum_relation += (output_relation.argmax(dim=1) == y_relation).sum().cpu().item()
            output_entity = output_entity.argmax(dim=2)
            for x, y in zip(y_entity, output_entity):
                if not (False in (x == y)):
                    train_acc_sum_entity += 1
            n += y_relation.shape[0]
            batch_count += 1
        valid_acc_relation, valid_acc_entity = evaluate_accuracy_relation(valid_iter, net)
        print('epoch %d, loss %.4f, train acc %.3f %.3f, valid acc %.3f %.3f, time %.1f sec'
              % (epoch + 1, train_l_sum / batch_count, train_acc_sum_relation / n, train_acc_sum_entity / n,
                 valid_acc_relation, valid_acc_entity,
                 time.time() - start))


def main():
    all_label = ['Cause-Effect', 'Component-Whole', 'Entity-Destination', 'Product-Producer', 'Entity-Origin',
                 'Member-Collection', 'Message-Topic', 'Content-Container', 'Instrument-Agency', 'Other']
    BIOES_to_index = {'O': 0, 'B': 1, 'I': 2, 'E': 3, 'S': 4}
    label_to_index = {label: idx for idx, label in enumerate(all_label)}
    nltk.data.path.insert(0, './nltk_data')
    DATA_ROOT = '../data'
    model_filename = '../output/rnn.pt'
    output_filename = '../output/output.txt'
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    batch_size = 64

    # 预处理
    data_train, tags_relation, tags_entity, data_test = load_data()
    counter = collections.Counter([token for tokens in data_train for token in tokens])
    vocab = Vocab.Vocab(counter, min_freq=2)  # 建立单词表
    tensor_train, tensor_test = data_to_tensor(data_train, vocab), data_to_tensor(data_test, vocab)
    tensor_tags_relation = torch.Tensor([label_to_index[tag] for tag in tags_relation]).long()
    index_tags_entity = [[[vocab.stoi[x] for x in entity] for entity in sample] for sample in tags_entity]
    tensor_tags_entity = torch.zeros(tensor_train.shape).long()
    # BIOES 标记
    for i in range(tensor_train.shape[0]):
        entity = index_tags_entity[i]
        sample = tensor_train[i]
        for x in entity:
            start = (sample == x[0]).nonzero()[0]  # 查找实体的位置
            length = len(x)
            if length == 1:
                tensor_tags_entity[i][start] = BIOES_to_index['S']
            else:
                tensor_tags_entity[i][start] = BIOES_to_index['B']
                for j in range(length - 2):
                    tensor_tags_entity[i][start + j + 1] = BIOES_to_index['I']
                tensor_tags_entity[i][start + length - 1] = BIOES_to_index['E']
    split = int(len(data_train) * 0.8)
    train_set = Data.TensorDataset(tensor_train[:split], tensor_tags_relation[:split], tensor_tags_entity[:split])
    valid_set = Data.TensorDataset(tensor_train[split:], tensor_tags_relation[split:], tensor_tags_entity[split:])
    train_iter = Data.DataLoader(train_set, batch_size, shuffle=True)
    valid_iter = Data.DataLoader(valid_set, batch_size)

    # 训练
    embed_size, num_hiddens, num_layers, class_num = 100, 50, 2, len(all_label)
    lr, num_epochs = 0.01, 100
    net = BiRNN(vocab, embed_size, num_hiddens, num_layers, class_num)
    glove_vocab = Vocab.GloVe(name='6B', dim=100, cache=os.path.join(DATA_ROOT, "glove"))
    net.embedding.weight.data.copy_(load_pretrained_embedding(vocab.itos, glove_vocab))
    net.embedding.weight.requires_grad = False  # 直接加载预训练好的, 所以不需要更新它
    optimizer = torch.optim.Adam(filter(lambda p: p.requires_grad, net.parameters()),
                                 lr=lr)  # 要过滤掉不计算梯度的embedding参数
    loss = nn.CrossEntropyLoss(reduction='none')
    train(train_iter, valid_iter, net, loss, optimizer, device, num_epochs)

    with open(output_filename, 'w') as f:
        y_relation, y_entity = net(tensor_test.to(device))
        result_relation = y_relation.argmax(dim=1)
        result_BOIES = y_entity.argmax(dim=2)
        for relation, words, BIOES in zip(result_relation, tensor_test, result_BOIES):
            entity1, entity2 = '', ''
            i = 0
            try:
                while BIOES[i] == 0:
                    i += 1
                while BIOES[i] != 0:
                    entity1 += vocab.itos[words[i]] + ' '
                    i += 1
            except:
                entity1 = 'body '
            try:
                while BIOES[i] == 0:
                    i += 1
                while BIOES[i] != 0:
                    entity2 += vocab.itos[words[i]] + ' '
                    i += 1
            except:
                entity2 = 'suitcase '
            f.write(all_label[relation] + '&' + entity1[:-1] + ',' + entity2[:-1] + '\n')


if __name__ == '__main__':
    main()
