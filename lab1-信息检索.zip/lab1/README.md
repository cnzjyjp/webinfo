## README

##### 运行环境

Python3.7

可能需要安装的库、包或模块有nltk、numpy、pickle等（或根据运行时提示）

**注意**：提交的src目录适用于linux系统；在windows10系统的测试下，可能因为库的原因，`src/nltk_data/tokenizers/punkt/PY3`下的`english.pickle`需要将路径移动到`PY3`外面，即`src/nltk_data/tokenizers/punkt`。如果仍有问题请参考控制台的报告，会指出试图在哪里读取这个文件'Attempted to load ...'，将`english.pickle`移动到指定路径即可。

##### 运行方式

按照所提交的文件路径就能让程序正确调用执行所需的如停用词库等文件，直接运行即可。

如果没有对数据进行第一次预处理（即output路径下没有文件），则会先对数据进行预处理生成预处理文件；如果已经有预处理文件则会进行读取。这一步结束之后，可以在控制台中输入布尔表达式或者要搜索的句子进行查询。

我们已经在output文件夹内提供了预处理的生成文件，所以如果按照路径运行程序，则程序会读取预处理文件，读取完成后可以在控制台进行搜索。

##### 关键函数说明

###### 布尔查询

`_init_`用于程序启动，先检查是否有预处理文件，有则调用load开头的函数读取，无则调用get开头的函数用于生成；

get:

`get_data`用于生成预处理文件，调用`get_all_file`读取文件，生成单词索引（见“文件说明“部分）和进行预处理，然后调用`max_1000`对前1000个单词建立单词索引和统计；

`get_all_file`在读取文件后调用`preprocessing`进行预处理，调用`stopword_and_stem`进行分词、词根化、去停用词；

`get_invert_index`在上述预处理完后生成倒排索引表。

load:

`load_index`,`load_data`,`load_invert_index`分别用于读取单词索引、前1000个单词、倒排索引表。

在程序得到需要的数据后，`_init_`结束，然后执行`search`函数调用`bool_search`进行布尔查询。

###### 语义查询

基本的控制流和处理数据的函数都是和布尔查询是一样的，只不过将`_init_`中用于生成倒排索引表的

`get_invert_index`换成用于计算tf-idf的`get_tf_idf`,同理`load_invert_index`改成了`load_tf_idf`,然后`search`调用的是`semantic_search`进行语义查询。



涉及具体算法的函数分析会写在实验报告中。

##### 文件说明

output下的生成文件包括：

###### index.pbz2

**实验要求以外的文件**，单词和数字的一一映射表，有这个索引就可以在其他文件中用数字代替单词，节约空间；

###### invert_index.pbz2

布尔检索的倒排索引表；

###### preprocessed_data.pbz2

经过预处理的前1000个单词的文档集合，统计的形式是data\[文件索引\]\[单词索引\];

###### tf_idf.pbz2

语义检索的tf-idf表。