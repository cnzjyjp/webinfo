import os
import nltk
import pickle
import bz2
import time
import functools
import numpy as np
from collections import Counter
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from nltk.tokenize import word_tokenize


# 用于debug的装饰器
def timer(func):
    @functools.wraps(func)
    def wraper(*args, **kargs):
        start_time = time.time()
        print(f'+++ function {func.__name__} start')
        value = func(*args, **kargs)
        print(f'--- function {func.__name__} end, spend {time.time() - start_time} s')
        return value

    return wraper


class Data():
    def __init__(self):
        self.root_dir = '../dataset/maildir'
        self.index_filename = '../output/index.pbz2'
        self.data_filename = '../output/preprocessed_data.pbz2'
        self.tf_idf_filename = '../output/tf_idf.pbz2'
        nltk.data.path.insert(0, './nltk_data')
        # nltk.download('stopwords', 'punkt')
        self.ps = PorterStemmer()
        self.stopwords_set = set(stopwords.words('english'))
        self.index_to_file = []  # 文件名索引
        self.index_to_vocab = []  # 单词索引
        self.vocab_to_index = dict()
        self.data = dict()  # key 是文件名，value 是 dict，它的 key 为单词，value 为数量
        if os.path.exists(self.index_filename):
            self.load_index()
            if os.path.exists(self.tf_idf_filename):
                self.load_tf_idf()
            else:
                self.load_data()
                self.get_tf_idf()
        else:
            self.get_data()
            self.get_tf_idf()

    @timer
    def load_tf_idf(self):
        with bz2.BZ2File(self.tf_idf_filename, 'rb') as f:
            time0 = time.time()
            print(f'load td_idf from {self.tf_idf_filename}...')
            (self.df, self.tf_idf, self.tf_idf_norm) = pickle.load(f)
            print(f'load finished, {time.time() - time0} s')

    @timer
    def load_index(self):
        with bz2.BZ2File(self.index_filename, 'rb') as f:
            (self.index_to_file, self.index_to_vocab, self.vocab_to_index) = pickle.load(f)
        self.file_count = len(self.index_to_file)
        self.vocab_count = len(self.index_to_vocab)
        print(f'{self.file_count} files, {self.vocab_count} vocabularies')

    @timer
    def load_data(self):
        with bz2.BZ2File(self.data_filename, 'rb') as f:
            self.data = pickle.load(f)

    @timer
    def max_1000(self):
        # 只对频率在前 1000 的词语建立索引
        vocab_count = np.zeros((len(self.vocab_to_index)))
        for tokens in self.data.values():
            for vocab_index, count in tokens.items():
                vocab_count[vocab_index] += count
        max_1000 = np.argsort(-vocab_count)[:1000]
        index_old_to_new = {old: new for new, old in enumerate(max_1000)}
        self.index_to_vocab = [self.index_to_vocab[i] for i in max_1000]
        self.vocab_to_index = {vocab: index for index, vocab in enumerate(self.index_to_vocab)}
        new_data = dict()
        for filename, tokens in self.data.items():
            tmp = dict()
            for vocab_index, count in tokens.items():
                if vocab_index in max_1000:
                    tmp[index_old_to_new[vocab_index]] = count
            new_data[filename] = tmp
        self.data = new_data

    @timer
    def get_data(self):
        # 获取邮件数据
        self.last_time = time.time()
        self.get_all_file(self.root_dir)
        self.max_1000()
        with bz2.BZ2File(self.index_filename, 'wb') as f:
            print(f'dump index to {self.index_filename}...')
            pickle.dump((self.index_to_file, self.index_to_vocab, self.vocab_to_index), f)
            print('dump finished')
        self.file_count = len(self.index_to_file)
        self.vocab_count = len(self.index_to_vocab)
        print(f'{self.file_count} files, {self.vocab_count} vocabularies')
        with bz2.BZ2File(self.data_filename, 'wb') as f:
            print(f'dump data to {self.data_filename}...')
            pickle.dump((self.data), f)
            print('dump finished')

    @timer
    def get_tf_idf(self):
        tf = np.zeros((self.file_count, self.vocab_count))
        self.df = np.zeros((self.vocab_count))
        self.tf_idf = np.zeros((self.file_count, self.vocab_count))
        for file, vocab_dict in self.data.items():
            for vocab, count in vocab_dict.items():
                tf[file][vocab] = count
                self.df[vocab] += 1
        for i in range(self.file_count):
            for j in range(self.vocab_count):
                if tf[i][j] != 0:
                    self.tf_idf[i][j] = (1 + np.log(tf[i][j])) * np.log(self.file_count / self.df[j])
        self.tf_idf_norm = np.linalg.norm(self.tf_idf, axis = 1)
        with bz2.BZ2File(self.tf_idf_filename, 'wb') as f:
            print(f'dump data to {self.tf_idf_filename}...')
            pickle.dump((self.df, self.tf_idf, self.tf_idf_norm), f)
            print('dump finished')

    def stopword_and_stem(self, input):
        return [self.ps.stem(token) for token in input if token not in self.stopwords_set]

    def preprocessing(self, lines, header = True):
        result = []
        for line in lines:
            tokens = word_tokenize(line.lower())
            if header:
                if line.startswith('Subject: '):
                    result += self.stopword_and_stem(tokens[2:])
                elif line.startswith('X-FileName: '):
                    header = False
            else:
                result += self.stopword_and_stem(tokens)
        result = Counter(result)  # 将邮件内容转化为 dict，key 是单词，value 是出现次数
        for i, vocab in enumerate(list(result.keys())):
            try:
                vocab_index = self.vocab_to_index[vocab]
            except:
                vocab_index = len((self.index_to_vocab))
                self.index_to_vocab.append(vocab)
                self.vocab_to_index[vocab] = vocab_index
            result[vocab_index] = result.pop(vocab)
        return result

    def get_all_file(self, path):
        if os.path.isdir(path):
            file_list = os.listdir(path)
            for sub_path in file_list:
                self.get_all_file(path + '/' + sub_path)
        else:
            with open(path, 'r', errors='replace') as f:
                lines = f.readlines()
                self.index_to_file.append(path)
                self.data[len(self.index_to_file) - 1] = self.preprocessing(lines)
                if len(self.data) % 1000 == 0:
                    print(f'{len(self.data)} files , {time.time() - self.last_time}s')
                    self.last_time = time.time()

    def search(self):
        while True:
            print("input the expression:")
            # 输入要搜索的句子
            expresion = input()
            tokens = self.stopword_and_stem(word_tokenize(expresion.lower()))
            tf_idf_Q = np.zeros(self.vocab_count)
            for token, count in Counter(tokens).items():
                try:
                    vocab_index = self.vocab_to_index[token]
                except:
                    continue
                tf_idf_Q[vocab_index] = (1 + np.log(count)) * np.log(self.file_count / self.df[vocab_index])
            result = self.semantic_search(10, tf_idf_Q)
            if len(result) != 0:
                for file_index, value in result.items():
                    print(f'{self.index_to_file[file_index]}, cos={value}')
                print(f'total {len(result)} results:')
            else:
                print('not found')

    def semantic_search(self, topk, tf_idf_Q):
        Q_norm = np.linalg.norm(tf_idf_Q)
        cos = np.dot(self.tf_idf, tf_idf_Q) / (self.tf_idf_norm * Q_norm)
        topk = np.argsort(-cos)[:topk]
        result = {i:cos[i] for i in topk}
        return result

data = Data()
data.search()
