import os
import nltk
import pickle
import bz2
import time
import functools
import numpy as np
from collections import Counter
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from nltk.tokenize import word_tokenize


# 用于debug的装饰器
def timer(func):
    @functools.wraps(func)
    def wraper(*args, **kargs):
        start_time = time.time()
        print(f'+++ function {func.__name__} start')
        value = func(*args, **kargs)
        print(f'--- function {func.__name__} end, spend {time.time() - start_time} s')
        return value

    return wraper


class Data():
    def __init__(self):
        self.root_dir = '../dataset/maildir'
        self.index_filename = '../output/index.pbz2'
        self.data_filename = '../output/preprocessed_data.pbz2'
        self.invert_index_filename = '../output/invert_index.pbz2'
        nltk.data.path.insert(0, './nltk_data')
        # nltk.download('stopwords', 'punkt')
        self.ps = PorterStemmer()
        self.index_to_file = []  # 文件名索引
        self.index_to_vocab = []  # 单词索引
        self.vocab_to_index = dict()
        # self.data 和 self.invert_index 的内容都使用数字索引，以减小存储空间
        self.data = dict()  # key 是文件名，value 是 dict，它的 key 为单词，value 为数量
        self.invert_index = dict()  # key 是文件名，value 是单词集合
        if os.path.exists(self.index_filename):
            self.load_index()
            if os.path.exists(self.invert_index_filename):
                self.load_invert_index()
            else:
                self.load_data()
                self.get_invert_index()
        else:
            self.get_data()
            self.get_invert_index()
        self.all_document = set(range(len(self.index_to_file)))
        self.op_order = {'(': 0, 'or': 1, 'and': 2, 'not': 3}

    @timer
    def load_index(self):
        with bz2.BZ2File(self.index_filename, 'rb') as f:
            (self.index_to_file, self.index_to_vocab, self.vocab_to_index) = pickle.load(f)
        print(f'{len(self.index_to_file)} files, {len(self.index_to_vocab)} vocabularies')

    @timer
    def load_data(self):
        with bz2.BZ2File(self.data_filename, 'rb') as f:
            self.data = pickle.load(f)

    @timer
    def load_invert_index(self):
        with bz2.BZ2File(self.invert_index_filename, 'rb') as f:
            self.invert_index = pickle.load(f)

    @timer
    def max_1000(self):
        # 只对频率在前 1000 的词语建立索引
        vocab_count = np.zeros((len(self.vocab_to_index)))
        for tokens in self.data.values():
            for vocab_index, count in tokens.items():
                vocab_count[vocab_index] += count
        max_1000 = np.argsort(-vocab_count)[:1000]
        index_old_to_new = {old: new for new, old in enumerate(max_1000)}
        self.index_to_vocab = [self.index_to_vocab[i] for i in max_1000]
        self.vocab_to_index = {vocab: index for index, vocab in enumerate(self.index_to_vocab)}
        new_data = dict()
        for filename, tokens in self.data.items():
            tmp = dict()
            for vocab_index, count in tokens.items():
                if vocab_index in max_1000:
                    tmp[index_old_to_new[vocab_index]] = count
            new_data[filename] = tmp
        self.data = new_data

    @timer
    def get_data(self):
        # 获取邮件数据
        self.stopwords_set = set(stopwords.words('english'))
        self.last_time = time.time()
        self.get_all_file(self.root_dir)
        self.max_1000()
        with bz2.BZ2File(self.index_filename, 'wb') as f:
            print(f'dump index to {self.index_filename}...')
            pickle.dump((self.index_to_file, self.index_to_vocab, self.vocab_to_index), f)
            print('dump finished')
        print(f'{len(self.index_to_file)} files, {len(self.index_to_vocab)} vocabularies')
        with bz2.BZ2File(self.data_filename, 'wb') as f:
            print(f'dump data to {self.data_filename}...')
            pickle.dump((self.data), f)
            print('dump finished')

    @timer
    def get_invert_index(self):
        self.invert_index = {}
        for file_name, word_set in self.data.items():
            for word in word_set.keys():
                try:
                    tmp = self.invert_index[word]
                    tmp.add(file_name)
                except:
                    self.invert_index[word] = {file_name}
        with bz2.BZ2File(self.invert_index_filename, 'wb') as f:
            print(f'dump invert index to {self.invert_index_filename}...')
            pickle.dump(self.invert_index, f)
            print('dump finished')

    def stopword_and_stem(self, input):
        return [self.ps.stem(token) for token in input if token not in self.stopwords_set]

    def preprocessing(self, lines):
        result = []
        header = True
        for line in lines:
            tokens = word_tokenize(line.lower())
            if header:
                if line.startswith('Subject: '):
                    result += self.stopword_and_stem(tokens[2:])
                elif line.startswith('X-FileName: '):
                    header = False
            else:
                result += self.stopword_and_stem(tokens)
        result = Counter(result)  # 将邮件内容转化为 dict，key 是单词，value 是出现次数
        for vocab in list(result.keys()):
            try:
                vocab_index = self.vocab_to_index[vocab]
            except:
                vocab_index = len((self.index_to_vocab))
                self.index_to_vocab.append(vocab)
                self.vocab_to_index[vocab] = vocab_index
            result[vocab_index] = result.pop(vocab)
        return result

    def get_all_file(self, path):
        if os.path.isdir(path):
            file_list = os.listdir(path)
            for sub_path in file_list:
                self.get_all_file(path + '/' + sub_path)
        else:
            with open(path, 'r', errors='replace') as f:
                lines = f.readlines()
                self.index_to_file.append(path)
                self.data[len(self.index_to_file) - 1] = self.preprocessing(lines)
                if len(self.data) % 1000 == 0:
                    print(f'{len(self.data)} files , {time.time() - self.last_time}s')
                    self.last_time = time.time()

    def bool_search(self, expresion):
        operator_stack, value_stack = [], []  # value_stack的元素是set
        inputs = expresion.split()

        def calculate(op):
            value1 = value_stack.pop()
            if op == 'not':
                value_stack.append(self.all_document - value1)
            elif op == 'and':
                value2 = value_stack.pop()
                value_stack.append(value1 & value2)
            elif op == 'or':
                value2 = value_stack.pop()
                value_stack.append(value1 | value2)

        for x in inputs:
            if x not in ['and', 'or', 'not', '(', ')']:
                # 如果是单词
                word = self.ps.stem(x)
                try:
                    word_index = self.vocab_to_index[word]
                    value = self.invert_index[word_index]
                except:
                    # 如果倒排表不存在该词，则返回空集
                    value = set()
                value_stack.append(value)
            elif x == '(':
                operator_stack.append(x)
            elif x == ')':
                op = operator_stack.pop()
                while op != '(':
                    calculate(op)
                    op = operator_stack.pop()
            elif x in ['and', 'or', 'not']:
                if len(operator_stack) == 0:
                    # 如果operator_stack为空
                    operator_stack.append(x)
                else:
                    # 如果栈顶符号优先级大于x，则pop符号，归约，直到operator_stack为空
                    top_op = operator_stack[-1]
                    while self.op_order[top_op] >= self.op_order[x]:
                        _ = operator_stack.pop()
                        calculate(top_op)
                        if len(operator_stack) == 0:
                            break
                        top_op = operator_stack[-1]
                    operator_stack.append(x)
        while len(operator_stack) != 0:
            # operator_stack非空时
            op = operator_stack.pop()
            calculate(op)
        if len(value_stack) != 1:
            print(value_stack)
            print(operator_stack)
        assert len(value_stack) == 1
        return value_stack[0]

    def search(self):
        while True:
            print("input the expression:")
            # 输入的符号(单词，运算符)使用空格分隔,比如：apple and ( bisnuess or offer )
            expresion = input()
            result = self.bool_search(expresion)
            if len(result) != 0:
                for file_index in result:
                    print(self.index_to_file[file_index])
                print(f'total {len(result)} results:')
            else:
                print('not found')


data = Data()
data.search()
