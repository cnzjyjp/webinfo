import torch
from torch import tensor
import torch.utils.data as Data
from math import sqrt
import time
from torch import nn
import sys


def load_data():
    # 载入训练和测试数据
    # data: 每一项是[用户，电影，评分]
    # data_test: 每一项是[用户，电影]
    train_file = '../data/training.dat'
    test_file = '../data/testing.dat'
    data, tag, data_test = [], [], []
    with open(train_file, 'r') as f:
        lines = f.readlines()
        for line in lines:
            split = line.split(',')
            data.append([int(split[0]), int(split[1])])
            tag.append(int(split[2]))
    with open(test_file, 'r') as f:
        lines = f.readlines()
        for line in lines:
            split = line.split(',')
            data_test.append([int(i) for i in split[:2]])
    return tensor(data, dtype=torch.long), tensor(tag), tensor(data_test)


class SVDNet(nn.Module):
    def __init__(self, dim, num_user, num_film):
        super(SVDNet, self).__init__()
        self.embedding_user = nn.Embedding(num_user, dim)
        self.embedding_film = nn.Embedding(num_film, dim)

    def forward(self, inputs):
        user, film = inputs.split(1, dim=1)
        embedding_user = self.embedding_user(user.squeeze())
        embedding_film = self.embedding_film(film.squeeze())
        outputs = (embedding_film * embedding_user).sum(dim=1)
        return outputs


def train(train_iter, net, optimizer, device, num_epochs):
    net = net.to(device)
    print("training on ", device)
    for epoch in range(num_epochs):
        # sample_count = 0
        # sum = 0
        start = time.time()
        for x, y in train_iter:
            x = x.to(device)
            y = y.to(device)
            output = net(x)
            l = torch.sqrt(((output - y) ** 2).sum() / len(y))
            optimizer.zero_grad()
            l.backward()
            optimizer.step()
        print('epoch %d, loss %.4f, time %.1f sec' % (epoch + 1, l, time.time() - start))


def RMSE_valid(valid_set, net, device):
    with torch.no_grad():
        x, y = valid_set[:]
        x = x.to(device)
        y = y.to(device)
        net = net.to(device)
        output = net(x)
        processed_output = output.clone()
        for i, value in enumerate(output):
            tmp = round(value.item())
            if tmp < 0:
                tmp = 0
            elif tmp > 5:
                tmp = 5
            processed_output[i] = tmp
        l = sqrt(((processed_output - y) ** 2).sum() / len(output))
        print('loss %.4f' % l)


def main():
    batch_size = 1024
    try:
        dim = int(sys.argv[1])
    except:
        dim = 4
    lr, num_epochs = 0.01, 20
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    data, tag, data_test = load_data()
    num_user, num_film = (data.max(dim=0)[0] + 1).tolist()  # 用户和电影的最大编号
    P, Q = len(data), len(data_test)
    # data 8:2 分成train和valid集
    cut = int(0.8 * P)
    data_set = Data.TensorDataset(data, tag)
    train_set, valid_set = Data.random_split(data_set, [cut, P - cut])
    train_iter = Data.DataLoader(train_set, batch_size, shuffle=True)
    net = SVDNet(dim, num_user, num_film)
    optimizer = torch.optim.Adam(net.parameters(), lr=lr)

    # train
    now = time.localtime(int(time.time()))
    timestr = time.strftime("%m-%d-%H-%M", now)
    train(train_iter, net, optimizer, device, num_epochs)
    torch.save(net.state_dict(), f'../output/model{timestr}.pt')
    # net.load_state_dict(torch.load('../output/model02-27-10-35.pt'))

    RMSE_valid(valid_set, net, device)
    RMSE_valid(train_set, net, device)

    # predict
    output = net(data_test.to(device))
    with open(f'../output/predict{timestr}.txt', 'w') as f:
        for score in output.tolist():
            score1 = round(score)
            if score1 < 0:
                score1 = 0
            if score1 > 5:
                score1 = 5
            f.write(str(score1)+'\n')


if __name__ == '__main__':
    main()
